SIFT_ADHOC
• Execution Time (sec): 401.6273581981659
• Memory Usage (MB): 1050.87109375

| Rank | Matched Path | RANSAC Inliers | 
| :--- | :--- |:---------------| 
| 1 | 8987479080_32ab912d10_n.jpg | 451            | 
| 2 | 5796562389_ae43c83317_m.jpg | 7              | 
| 3 | 5512287917_9f5d3f0f98_n.jpg | 6              | 
| 4 | 4634716478_1cbcbee7ca.jpg | 0              | 
| 5 | 4897587985_f9293ea1ed.jpg | 0              | 
| 6 | 7197581386_8a51f1bb12_n.jpg | 0              | 
| 7 | 6250363717_17732e992e_n.jpg | 0              | 
| 8 | 17388674711_6dca8a2e8b_n.jpg | 0              | 
| 9 | 12094442595_297494dba4_m.jpg | 0              | 
| 10 | 14469481104_d0e29f7ffd.jpg | 0              |

ANSIOTROPIC_SIFT
• Execution Time (sec): 1683.496908903122
• Memory Usage (MB): 1949.9453125

| Rank | Matched Path | RANSAC Inliers | 
| :--- | :--- | :--- | 
| 1 | 8987479080_32ab912d10_n.jpg | 1693 | 
| 2 | 8691437509_9ac8441db7_n.jpg | 7 | 
| 3 | 4897587985_f9293ea1ed.jpg | 7 | 
| 4 | 5796562389_ae43c83317_m.jpg | 6 | 
| 5 | 14921511479_7b0a647795.jpg | 5 | 
| 6 | 7270523166_b62fc9e5f1_m.jpg | 0 | 
| 7 | 6323721068_3d3394af6d_n.jpg | 0 | 
| 8 | 4558562689_c8e2ab9f10.jpg | 0 | 
| 9 | 15760811380_4d686c892b_n.jpg | 0 | 
| 10 | 3998275481_651205e02d.jpg | 0 |